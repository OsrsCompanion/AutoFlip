from __future__ import annotations

import json
import os
from collections import defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any

DATA_DIR = os.path.join("data", "market_history")
SNAPSHOT_DIR = os.path.join(DATA_DIR, "snapshots")
ARCHIVE_DIR = os.path.join(DATA_DIR, "archive")
MONTH_ARCHIVE_DIR = os.path.join(ARCHIVE_DIR, "month")
TRACKED_ITEMS_PATH = os.path.join(DATA_DIR, "tracked_items.json")
CACHE_DIR = os.path.join("data", "cache")
CACHE_PATH = os.path.join(CACHE_DIR, "market_cache.json")

RETENTION_DAYS = 31
RAW_RETENTION_DAYS = 7
MIN_TRACKED_VOLUME = 1000
MIN_TRACKED_PRICE = 1_000_000
HOURLY_VOLUME_WINDOW_MINUTES = 60
MONTH_BUCKET_MINUTES = 150  # 2.5 hours -> 288 points over 30 days


# -----------------------------
# general helpers
# -----------------------------

def _utc_now() -> datetime:
    return datetime.now(UTC)


def _ensure_dirs() -> None:
    os.makedirs(SNAPSHOT_DIR, exist_ok=True)
    os.makedirs(MONTH_ARCHIVE_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)


def _bucket_for_time(dt: datetime | None = None) -> str:
    current = dt or _utc_now()
    minute = (current.minute // 5) * 5
    return current.replace(minute=minute, second=0, microsecond=0).isoformat()


def _date_path(dt: datetime) -> str:
    return os.path.join(SNAPSHOT_DIR, f"{dt.strftime('%Y-%m-%d')}.jsonl")


def _month_archive_path(dt: datetime) -> str:
    return os.path.join(MONTH_ARCHIVE_DIR, f"{dt.strftime('%Y-%m-%d')}.jsonl")


def _to_int(value: Any) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _record_from_item(item: dict[str, Any], snapshot_ts: str) -> dict[str, Any]:
    low = _to_int(item.get("low"))
    high = _to_int(item.get("high"))
    high_alch = max(
        _to_int(item.get("high_alch_value")),
        _to_int(item.get("high_alch")),
        _to_int(item.get("alch_value")),
        _to_int(item.get("high_alchemy_value")),
    )
    return {
        "snapshot_ts": snapshot_ts,
        "id": _to_int(item.get("id")),
        "name": str(item.get("name") or "Unknown item"),
        "low": low,
        "high": high,
        "recent_volume": _to_int(item.get("recent_volume")),
        "buy_limit": _to_int(item.get("limit")),
        "members": bool(item.get("members", False)),
        "high_alch": high_alch,
    }


def _read_json(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


def _write_json(path: str, payload: Any) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def _iter_jsonl(path: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                if isinstance(row, dict):
                    rows.append(row)
    except FileNotFoundError:
        pass
    return rows


def _append_jsonl(path: str, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with open(path, "a", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, separators=(",", ":")) + "\n")


def _parse_ts(value: str | None) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value))
    except Exception:
        return None


def _mean(values: list[float]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


def _safe_pct(base: float, current: float) -> float:
    if base <= 0:
        return 0.0
    return round(((base - current) / base) * 100, 3)


def _stability_pct(lows: list[int]) -> float:
    if not lows:
        return 0.0
    avg = _mean([float(v) for v in lows])
    if avg <= 0:
        return 0.0
    return round(((max(lows) - min(lows)) / avg) * 100, 3)


def _bucket_start(dt: datetime, minutes: int) -> datetime:
    base_minute = (dt.hour * 60 + dt.minute) // minutes * minutes
    hour = base_minute // 60
    minute = base_minute % 60
    return dt.replace(hour=hour % 24, minute=minute, second=0, microsecond=0)


def _load_recent_hour_volume_map(reference_time: datetime) -> dict[int, int]:
    """Sum the previous 55 minutes of raw 5-minute volumes.

    The current snapshot's 5-minute volume is added separately so the final
    effective window is one hour (12 x 5-minute periods).
    """
    _ensure_dirs()
    cutoff = reference_time - timedelta(minutes=55)
    totals: dict[int, int] = defaultdict(int)
    for name in sorted(os.listdir(SNAPSHOT_DIR)):
        if not name.endswith(".jsonl"):
            continue
        path = os.path.join(SNAPSHOT_DIR, name)
        for row in _iter_jsonl(path):
            ts = _parse_ts(row.get("snapshot_ts"))
            if not ts:
                continue
            if ts < cutoff or ts >= reference_time:
                continue
            item_id = _to_int(row.get("id"))
            if item_id <= 0:
                continue
            totals[item_id] += _to_int(row.get("recent_volume"))
    return dict(totals)


def _project_daily_volume(total_volume: int, sample_count: int) -> int:
    if total_volume <= 0 or sample_count <= 0:
        return 0
    return int(round(total_volume * (288 / sample_count)))


# -----------------------------
# tracking universe rules
# -----------------------------

def _load_tracked_items() -> dict[str, Any]:
    _ensure_dirs()
    data = _read_json(TRACKED_ITEMS_PATH, {"tracked_ids": {}, "updated_at": None})
    if not isinstance(data, dict):
        return {"tracked_ids": {}, "updated_at": None}
    tracked_ids = data.get("tracked_ids", {})
    if not isinstance(tracked_ids, dict):
        tracked_ids = {}
    return {"tracked_ids": tracked_ids, "updated_at": data.get("updated_at")}


def _save_tracked_items(payload: dict[str, Any]) -> None:
    _ensure_dirs()
    _write_json(TRACKED_ITEMS_PATH, payload)


def _tracking_reason(item: dict[str, Any], existing_reason: str | None, hourly_volume: int = 0) -> str | None:
    if existing_reason:
        return existing_reason
    low = _to_int(item.get("low"))
    high = _to_int(item.get("high"))
    price = max(low, high)
    if hourly_volume >= MIN_TRACKED_VOLUME:
        return "volume_1h"
    if price >= MIN_TRACKED_PRICE:
        return "high_value"
    return None


def _update_tracking_universe(items: list[dict[str, Any]], snapshot_bucket: str | None = None) -> dict[int, str]:
    payload = _load_tracked_items()
    tracked_ids = payload.get("tracked_ids", {})
    changed = False
    reference_time = _parse_ts(snapshot_bucket) or _utc_now()
    prior_hour_volume = _load_recent_hour_volume_map(reference_time)
    for item in items:
        item_id = _to_int(item.get("id"))
        if item_id <= 0:
            continue
        key = str(item_id)
        hourly_volume = prior_hour_volume.get(item_id, 0) + _to_int(item.get("recent_volume"))
        reason = _tracking_reason(item, tracked_ids.get(key), hourly_volume=hourly_volume)
        if reason and tracked_ids.get(key) != reason:
            tracked_ids[key] = reason
            changed = True
    if changed:
        payload["tracked_ids"] = tracked_ids
        payload["updated_at"] = _utc_now().isoformat()
        _save_tracked_items(payload)
    return {int(item_id): str(reason) for item_id, reason in tracked_ids.items()}


def load_tracked_universe() -> dict[str, Any]:
    payload = _load_tracked_items()
    tracked_ids = payload.get("tracked_ids", {})
    return {
        "tracked_ids": tracked_ids,
        "updated_at": payload.get("updated_at"),
        "tracked_count": len(tracked_ids),
    }


# -----------------------------
# cache helpers
# -----------------------------

def load_market_cache() -> dict[str, Any]:
    _ensure_dirs()
    if not os.path.exists(CACHE_PATH):
        return {"updated_at": None, "snapshot_bucket": None, "items": []}
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
            if isinstance(data, dict):
                data.setdefault("items", [])
                return data
    except Exception:
        pass
    return {"updated_at": None, "snapshot_bucket": None, "items": []}


def save_market_cache(cache: dict[str, Any]) -> None:
    _ensure_dirs()
    with open(CACHE_PATH, "w", encoding="utf-8") as handle:
        json.dump(cache, handle, indent=2)


# -----------------------------
# raw snapshot storage
# -----------------------------

def append_snapshot(items: list[dict[str, Any]], snapshot_bucket: str | None = None) -> str:
    _ensure_dirs()
    bucket = snapshot_bucket or _bucket_for_time()
    cache = load_market_cache()
    if cache.get("snapshot_bucket") == bucket:
        return bucket

    tracked_items = _update_tracking_universe(items, snapshot_bucket=bucket)
    dt = datetime.fromisoformat(bucket)
    path = _date_path(dt)
    rows: list[dict[str, Any]] = []
    for item in items:
        item_id = _to_int(item.get("id"))
        if item_id <= 0:
            continue
        if item_id not in tracked_items:
            continue
        rows.append(_record_from_item(item, bucket))
    _append_jsonl(path, rows)

    prune_old_snapshots(reference_time=dt)
    compact_old_raw_history(reference_time=dt)
    return bucket


def prune_old_snapshots(reference_time: datetime | None = None) -> None:
    _ensure_dirs()
    cutoff = (reference_time or _utc_now()) - timedelta(days=RETENTION_DAYS)

    for name in os.listdir(SNAPSHOT_DIR):
        if not name.endswith(".jsonl"):
            continue
        try:
            file_date = datetime.strptime(name[:-6], "%Y-%m-%d").replace(tzinfo=UTC)
        except Exception:
            continue
        if file_date.date() < cutoff.date():
            try:
                os.remove(os.path.join(SNAPSHOT_DIR, name))
            except FileNotFoundError:
                pass

    for name in os.listdir(MONTH_ARCHIVE_DIR):
        if not name.endswith(".jsonl"):
            continue
        try:
            file_date = datetime.strptime(name[:-6], "%Y-%m-%d").replace(tzinfo=UTC)
        except Exception:
            continue
        if file_date.date() < cutoff.date():
            try:
                os.remove(os.path.join(MONTH_ARCHIVE_DIR, name))
            except FileNotFoundError:
                pass


def _aggregate_rows(rows: list[dict[str, Any]], bucket_minutes: int) -> list[dict[str, Any]]:
    grouped: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        ts = _parse_ts(row.get("snapshot_ts"))
        item_id = _to_int(row.get("id"))
        if not ts or item_id <= 0:
            continue
        bucket_ts = _bucket_start(ts, bucket_minutes).isoformat()
        grouped[(item_id, bucket_ts)].append(row)

    aggregated: list[dict[str, Any]] = []
    for (_, bucket_ts), group in grouped.items():
        lows = [_to_int(entry.get("low")) for entry in group if _to_int(entry.get("low")) > 0]
        highs = [_to_int(entry.get("high")) for entry in group if _to_int(entry.get("high")) > 0]
        volumes = [_to_int(entry.get("recent_volume")) for entry in group]
        if not lows or not highs:
            continue
        first = group[0]
        aggregated.append(
            {
                "snapshot_ts": bucket_ts,
                "id": _to_int(first.get("id")),
                "name": str(first.get("name") or "Unknown item"),
                "low": round(_mean([float(v) for v in lows]), 3),
                "high": round(_mean([float(v) for v in highs]), 3),
                "recent_volume": sum(volumes),
                "buy_limit": _to_int(first.get("buy_limit")),
                "members": bool(first.get("members", False)),
                "high_alch": _to_int(first.get("high_alch")),
                "sample_count": len(group),
                "min_low": min(lows),
                "max_low": max(lows),
                "min_high": min(highs),
                "max_high": max(highs),
                "bucket_minutes": bucket_minutes,
                "is_compacted": True,
            }
        )
    aggregated.sort(key=lambda row: (row.get("snapshot_ts", ""), row.get("id", 0)))
    return aggregated


def compact_old_raw_history(reference_time: datetime | None = None) -> None:
    _ensure_dirs()
    reference = reference_time or _utc_now()
    raw_cutoff = reference - timedelta(days=RAW_RETENTION_DAYS)

    for name in sorted(os.listdir(SNAPSHOT_DIR)):
        if not name.endswith(".jsonl"):
            continue
        try:
            file_date = datetime.strptime(name[:-6], "%Y-%m-%d").replace(tzinfo=UTC)
        except Exception:
            continue
        if file_date.date() >= raw_cutoff.date():
            continue

        raw_path = os.path.join(SNAPSHOT_DIR, name)
        rows = _iter_jsonl(raw_path)
        if not rows:
            try:
                os.remove(raw_path)
            except FileNotFoundError:
                pass
            continue

        aggregated = _aggregate_rows(rows, MONTH_BUCKET_MINUTES)
        archive_path = _month_archive_path(file_date)
        if aggregated:
            with open(archive_path, "w", encoding="utf-8") as handle:
                for row in aggregated:
                    handle.write(json.dumps(row, separators=(",", ":")) + "\n")
        try:
            os.remove(raw_path)
        except FileNotFoundError:
            pass


# -----------------------------
# loading mixed history
# -----------------------------

def _load_raw_history(days: int) -> list[dict[str, Any]]:
    _ensure_dirs()
    cutoff = _utc_now() - timedelta(days=days)
    records: list[dict[str, Any]] = []
    for name in sorted(os.listdir(SNAPSHOT_DIR)):
        if not name.endswith(".jsonl"):
            continue
        try:
            file_date = datetime.strptime(name[:-6], "%Y-%m-%d").replace(tzinfo=UTC)
        except Exception:
            continue
        if file_date.date() < cutoff.date():
            continue
        path = os.path.join(SNAPSHOT_DIR, name)
        for record in _iter_jsonl(path):
            ts = _parse_ts(record.get("snapshot_ts"))
            if not ts or ts < cutoff:
                continue
            records.append(record)
    return records


def _load_month_archive(days: int) -> list[dict[str, Any]]:
    _ensure_dirs()
    cutoff = _utc_now() - timedelta(days=days)
    records: list[dict[str, Any]] = []
    for name in sorted(os.listdir(MONTH_ARCHIVE_DIR)):
        if not name.endswith(".jsonl"):
            continue
        try:
            file_date = datetime.strptime(name[:-6], "%Y-%m-%d").replace(tzinfo=UTC)
        except Exception:
            continue
        if file_date.date() < cutoff.date():
            continue
        path = os.path.join(MONTH_ARCHIVE_DIR, name)
        for record in _iter_jsonl(path):
            ts = _parse_ts(record.get("snapshot_ts"))
            if not ts or ts < cutoff:
                continue
            records.append(record)
    return records


def load_history_records(days: int = RETENTION_DAYS) -> list[dict[str, Any]]:
    reference = _utc_now()
    raw_cutoff = reference - timedelta(days=RAW_RETENTION_DAYS)
    overall_cutoff = reference - timedelta(days=days)

    raw_records = _load_raw_history(days=min(days, RAW_RETENTION_DAYS))
    archive_records: list[dict[str, Any]] = []
    if days > RAW_RETENTION_DAYS and overall_cutoff < raw_cutoff:
        archive_records = _load_month_archive(days=days)

    merged = archive_records + raw_records
    merged.sort(key=lambda row: row.get("snapshot_ts", ""))
    return merged


# -----------------------------
# cache + analytics
# -----------------------------

def build_market_cache(items: list[dict[str, Any]], snapshot_bucket: str | None = None) -> dict[str, Any]:
    bucket = snapshot_bucket or _bucket_for_time()
    records = load_history_records(days=RETENTION_DAYS)
    by_item: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        item_id = _to_int(record.get("id"))
        if item_id > 0:
            by_item[item_id].append(record)

    tracked_items = _load_tracked_items().get("tracked_ids", {})
    now = datetime.fromisoformat(bucket)
    hour_cutoff = now - timedelta(hours=1)
    day_cutoff = now - timedelta(days=1)
    week_cutoff = now - timedelta(days=7)

    cached_items: list[dict[str, Any]] = []
    for item in items:
        item_id = _to_int(item.get("id"))
        if item_id <= 0 or str(item_id) not in tracked_items:
            continue

        history = sorted(by_item.get(item_id, []), key=lambda row: row.get("snapshot_ts", ""))
        lows_month = [int(round(float(row.get("low") or 0))) for row in history if float(row.get("low") or 0) > 0]
        highs_month = [int(round(float(row.get("high") or 0))) for row in history if float(row.get("high") or 0) > 0]

        lows_day: list[int] = []
        highs_day: list[int] = []
        lows_week: list[int] = []
        highs_week: list[int] = []
        volumes_hour: list[int] = []
        volumes_day: list[int] = []
        volumes_week: list[int] = []
        volumes_month: list[int] = []
        for row in history:
            ts = _parse_ts(row.get("snapshot_ts"))
            if not ts:
                continue
            low = int(round(float(row.get("low") or 0)))
            high = int(round(float(row.get("high") or 0)))
            volume = _to_int(row.get("recent_volume"))
            if ts >= hour_cutoff:
                volumes_hour.append(volume)
            if ts >= day_cutoff:
                volumes_day.append(volume)
                if low > 0:
                    lows_day.append(low)
                if high > 0:
                    highs_day.append(high)
            if ts >= week_cutoff:
                volumes_week.append(volume)
                if low > 0:
                    lows_week.append(low)
                if high > 0:
                    highs_week.append(high)
            volumes_month.append(volume)

        low = _to_int(item.get("low"))
        high = _to_int(item.get("high"))
        snapshot_volume_5m = _to_int(item.get("recent_volume"))
        recent_volume = sum(volumes_hour) if volumes_hour else snapshot_volume_5m
        buy_limit = _to_int(item.get("limit"))
        spread = max(high - low, 0)
        spread_pct = round((spread / low) * 100, 3) if low > 0 else 0.0
        profit_per_item = max(high - low - min(int(high * 0.02), 5_000_000), 0)
        roi_pct = round((profit_per_item / low) * 100, 3) if low > 0 else 0.0

        day_low = min(lows_day) if lows_day else low
        day_high = max(highs_day) if highs_day else high
        week_low = min(lows_week) if lows_week else low
        week_high = max(highs_week) if highs_week else high
        month_low = min(lows_month) if lows_month else low
        month_high = max(highs_month) if highs_month else high
        avg_day_low = round(_mean([float(v) for v in lows_day]), 3) if lows_day else float(low)
        avg_week_low = round(_mean([float(v) for v in lows_week]), 3) if lows_week else float(low)
        avg_month_low = round(_mean([float(v) for v in lows_month]), 3) if lows_month else float(low)

        day_volume = sum(volumes_day)
        week_volume = sum(volumes_week)
        month_volume = sum(volumes_month)
        avg_daily_volume = _project_daily_volume(day_volume, len(volumes_day))
        high_alch = max(
            _to_int(item.get("high_alch_value")),
            _to_int(item.get("high_alch")),
            _to_int(item.get("alch_value")),
            _to_int(item.get("high_alchemy_value")),
        )

        cached_items.append(
            {
                "id": item_id,
                "name": str(item.get("name") or f"Item {item_id}"),
                "buy_price": low,
                "sell_price": high,
                "recent_volume": recent_volume,
                "snapshot_volume_5m": snapshot_volume_5m,
                "day_volume": day_volume,
                "week_volume": week_volume,
                "month_volume": month_volume,
                "avg_daily_volume": avg_daily_volume,
                "buy_limit": buy_limit,
                "members": bool(item.get("members", False)),
                "spread": spread,
                "spread_pct": spread_pct,
                "profit_per_item": profit_per_item,
                "roi_pct": roi_pct,
                "day_low": day_low,
                "day_high": day_high,
                "week_low": week_low,
                "week_high": week_high,
                "month_low": month_low,
                "month_high": month_high,
                "avg_day_low": avg_day_low,
                "avg_week_low": avg_week_low,
                "avg_month_low": avg_month_low,
                "dip_vs_day_pct": _safe_pct(avg_day_low, float(low)),
                "dip_vs_week_pct": _safe_pct(avg_week_low, float(low)),
                "dip_vs_month_pct": _safe_pct(avg_month_low, float(low)),
                "stability_day_pct": _stability_pct(lows_day),
                "stability_week_pct": _stability_pct(lows_week),
                "stability_month_pct": _stability_pct(lows_month),
                "history_points": len(history),
                "tracking_reason": str(tracked_items.get(str(item_id)) or "volume"),
                "high_alch": high_alch,
                "updated_at": bucket,
            }
        )

    cache = {
        "updated_at": _utc_now().isoformat(),
        "snapshot_bucket": bucket,
        "items": sorted(cached_items, key=lambda item: item.get("name", "").lower()),
        "storage": {
            "raw_retention_days": RAW_RETENTION_DAYS,
            "compacted_bucket_minutes": MONTH_BUCKET_MINUTES,
            "month_points_target": 288,
        },
    }
    save_market_cache(cache)
    return cache


def ensure_history_and_cache(items: list[dict[str, Any]], snapshot_bucket: str | None = None) -> dict[str, Any]:
    bucket = append_snapshot(items, snapshot_bucket=snapshot_bucket)
    cache = load_market_cache()
    if cache.get("snapshot_bucket") != bucket or not cache.get("items"):
        return build_market_cache(items, snapshot_bucket=bucket)
    return cache


def search_cache(query: str = "", limit: int = 100) -> list[dict[str, Any]]:
    cache = load_market_cache()
    items = cache.get("items", []) if isinstance(cache, dict) else []
    text = (query or "").strip().lower()
    if not text:
        return items[:limit]
    exact = [item for item in items if item.get("name", "").lower() == text]
    starts = [item for item in items if item.get("name", "").lower().startswith(text) and item not in exact]
    contains = [item for item in items if text in item.get("name", "").lower() and item not in exact and item not in starts]
    return (exact + starts + contains)[:limit]


# -----------------------------
# graph data helpers
# -----------------------------

def _bucket_history(rows: list[dict[str, Any]], target_points: int) -> list[dict[str, Any]]:
    if not rows:
        return []
    if len(rows) <= target_points:
        return [
            {
                "snapshot_ts": row.get("snapshot_ts"),
                "low": round(float(row.get("low") or 0), 3),
                "high": round(float(row.get("high") or 0), 3),
                "recent_volume": _to_int(row.get("recent_volume")),
                "buy_limit": _to_int(row.get("buy_limit")),
                "sample_count": max(_to_int(row.get("sample_count")), 1),
                "min_low": _to_int(row.get("min_low") or row.get("low")),
                "max_high": _to_int(row.get("max_high") or row.get("high")),
                "is_compacted": bool(row.get("is_compacted", False)),
            }
            for row in rows
        ]

    bucket_size = max(1, len(rows) // target_points)
    if len(rows) % target_points:
        bucket_size += 1

    compacted: list[dict[str, Any]] = []
    for start in range(0, len(rows), bucket_size):
        group = rows[start : start + bucket_size]
        lows = [float(entry.get("low") or 0) for entry in group if float(entry.get("low") or 0) > 0]
        highs = [float(entry.get("high") or 0) for entry in group if float(entry.get("high") or 0) > 0]
        if not lows or not highs:
            continue
        compacted.append(
            {
                "snapshot_ts": group[-1].get("snapshot_ts"),
                "low": round(_mean(lows), 3),
                "high": round(_mean(highs), 3),
                "recent_volume": sum(_to_int(entry.get("recent_volume")) for entry in group),
                "buy_limit": max(_to_int(entry.get("buy_limit")) for entry in group),
                "sample_count": sum(max(_to_int(entry.get("sample_count")), 1) for entry in group),
                "min_low": min(int(round(value)) for value in lows),
                "max_high": max(int(round(value)) for value in highs),
                "is_compacted": True,
            }
        )
    return compacted[:target_points]


def get_item_history(item_id: int, window: str = "month") -> list[dict[str, Any]]:
    target_points = 288
    if window == "day":
        rows = [row for row in _load_raw_history(days=1) if _to_int(row.get("id")) == item_id]
        rows.sort(key=lambda row: row.get("snapshot_ts", ""))
        return _bucket_history(rows, target_points)

    if window == "week":
        rows = [row for row in _load_raw_history(days=7) if _to_int(row.get("id")) == item_id]
        rows.sort(key=lambda row: row.get("snapshot_ts", ""))
        return _bucket_history(rows, target_points)

    # month: use compacted archive for older data + raw data for recent week, then rebucket to 288.
    rows = [row for row in load_history_records(days=RETENTION_DAYS) if _to_int(row.get("id")) == item_id]
    rows.sort(key=lambda row: row.get("snapshot_ts", ""))
    return _bucket_history(rows, target_points)
