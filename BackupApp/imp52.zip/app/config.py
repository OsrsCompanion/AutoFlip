"""
Configuration loader.
Placeholder only.
"""