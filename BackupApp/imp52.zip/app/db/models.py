"""
Database models.
Placeholder only.
"""