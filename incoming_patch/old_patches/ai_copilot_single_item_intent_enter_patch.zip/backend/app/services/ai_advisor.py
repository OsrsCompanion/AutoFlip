from __future__ import annotations

import json
import math
import re
import time
from typing import Any

from openai import OpenAI

from app.services.ai_context import build_ai_context_for_query, load_market_cache
from app.services.recommendations import build_recommendations
from app.services.screen_snapshot import get_current_offers
from app.services.settings_store import load_settings, resolve_openai_api_key
from app.services.trade_decisions import build_trade_decisions

DEFAULT_MODEL = "gpt-5.4-mini"
MAX_ACTIONS = 3
MAX_PICKS = 3
AI_TIMEOUT_SECONDS = 10.5
FAST_PATH_PRESET_REPLIES = {
    "what should i replace if i will be away for 12 hours?": {
        "summary": "For a 12h window, swap out slower or thinner trades first.",
        "actions": [
            {"item": "Slowest-moving trades", "decision": "review", "reason": "Most likely to stall while you are offline."},
            {"item": "Thin-margin trades", "decision": "avoid", "reason": "Less room for drift over a longer hold."},
        ],
        "notes": [
            "Steadier, higher-volume items usually hold up better during offline windows.",
            "The plugin can narrow this into exact replacements once you upgrade.",
        ],
    },
    "which current trades look weakest and why?": {
        "summary": "Start with trades that combine slow movement and weak margin.",
        "actions": [
            {"item": "Slow-moving slots", "decision": "review", "reason": "Idle offers become dead weight fastest."},
            {"item": "Low-margin holds", "decision": "watch", "reason": "Small edge disappears first when prices drift."},
        ],
        "notes": [
            "Weakest usually means low velocity, low edge, or frequent repricing pressure.",
            "The plugin can rank every live slot once full tools are unlocked.",
        ],
    },
    "give me a preview-only 3-slot plan from my current setup.": {
        "summary": "Use a balanced 3-slot preview instead of forcing full deployment.",
        "actions": [
            {"item": "1 steadier slot", "decision": "consider", "reason": "Adds stability while you are away."},
            {"item": "1 medium-risk slot", "decision": "review", "reason": "Keeps upside without overcommitting budget."},
            {"item": "1 flexible slot", "decision": "hold", "reason": "Leaves room to rotate after fresh data."},
        ],
        "notes": [
            "A preview plan should spread risk rather than chase one item type.",
            "The plugin handles exact slot-by-slot assignment and quantities.",
        ],
    },
    "how should i lower risk without abandoning profit entirely?": {
        "summary": "Reduce reliance on volatile or slow items before cutting all upside.",
        "actions": [
            {"item": "High-volatility slots", "decision": "review", "reason": "These need more babysitting to stay efficient."},
            {"item": "Steadier volume items", "decision": "consider", "reason": "They usually carry lower stress over time."},
        ],
        "notes": [
            "Lower risk usually comes from smoother fills and more forgiving spreads.",
            "The plugin can convert this into an exact lower-risk allocation later.",
        ],
    },
}
PLANNING_KEYWORDS = (
    "best items",
    "all slots",
    "replace all",
    "full plan",
    "roadmap",
    "optimize all",
    "8 slots",
    "slot mix",
    "portfolio",
    "top trades",
    "full setup",
    "entire setup",
    "whole setup",
    "all my trades",
    "all my items",
    "rank these",
)
COMPARE_KEYWORDS = ("compare", "versus", "vs", "better than", "or")
NON_OSRS_BLOCKERS = (
    "math homework",
    "homework",
    "essay",
    "algebra",
    "geometry",
    "derivative",
)
STOPWORDS = {
    "a", "an", "and", "at", "be", "best", "buy", "can", "current", "flip", "for", "good", "how", "i", "if",
    "in", "is", "it", "my", "of", "on", "or", "price", "right", "sell", "should", "the", "to", "what", "which",
    "will", "with", "now", "much", "many", "hours", "hour", "away", "am", "me", "you", "your", "want", "save",
    "money", "period", "over", "during", "within", "from", "by", "please", "today", "tonight", "really", "exactly",
}


def _default_question() -> str:
    return "Which items look safest to review on the website right now?"


def _timing_ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 1)


def _extract_json_text(response) -> str:
    text = getattr(response, "output_text", "") or ""
    return text.strip() if text else ""


def _normalize_name(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _normalize_free_text(value: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", _normalize_name(value))


def _tokenize(value: str) -> list[str]:
    return [token for token in _normalize_free_text(value).split() if token]


def _safe_int(value: Any) -> int:
    try:
        return int(round(float(value or 0)))
    except Exception:
        return 0


def _safe_float(value: Any) -> float:
    try:
        return float(value or 0)
    except Exception:
        return 0.0


def _format_gp(value: Any) -> str:
    return f"{_safe_int(value):,} gp"


def _clean_user_prompt(user_message: str) -> str:
    text = str(user_message or "").strip()
    if not text:
        return ""
    return re.split(r"\n\s*Current trade decisions:|\n\s*Slot purpose settings:", text, maxsplit=1)[0].strip()


def _load_market_items() -> list[dict[str, Any]]:
    cache = load_market_cache()
    items = cache.get("items", []) if isinstance(cache, dict) else []
    return items if isinstance(items, list) else []


def _item_aliases(name: str) -> set[str]:
    aliases = { _normalize_free_text(name) }
    tokens = aliases.copy()
    for alias in list(tokens):
        parts = alias.split()
        if parts:
            last = parts[-1]
            if last.endswith("s") and len(last) > 3:
                aliases.add(" ".join(parts[:-1] + [last[:-1]]))
            else:
                aliases.add(" ".join(parts[:-1] + [last + "s"]))
    return {a for a in aliases if a}


def _item_match_score(prompt: str, item_name: str) -> int:
    prompt_norm = _normalize_free_text(prompt)
    prompt_tokens = set(_tokenize(prompt))
    item_norm = _normalize_free_text(item_name)
    if not item_norm:
        return -1
    item_tokens = [t for t in item_norm.split() if t not in STOPWORDS]
    if not item_tokens:
        return -1

    score = 0
    aliases = _item_aliases(item_name)
    if any(alias in prompt_norm for alias in aliases):
        longest = max(len(alias) for alias in aliases if alias in prompt_norm)
        score += 20000 + longest

    overlap = len(set(item_tokens) & prompt_tokens)
    if overlap:
        score += overlap * 500
        if overlap == len(item_tokens):
            score += 5000
        elif overlap >= max(1, math.ceil(len(item_tokens) * 0.7)):
            score += 1800

    if item_norm in prompt_norm:
        score += 6000
    elif len(item_tokens) == 1 and item_tokens[0] in prompt_tokens:
        score += 2500

    return score


def _resolve_market_items(prompt: str, limit: int = 4) -> list[dict[str, Any]]:
    items = _load_market_items()
    scored: list[tuple[int, str, dict[str, Any]]] = []
    for item in items:
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        score = _item_match_score(prompt, name)
        if score < 2200:
            continue
        scored.append((score, _normalize_name(name), item))
    scored.sort(key=lambda row: (-row[0], row[1]))

    unique: list[tuple[int, dict[str, Any]]] = []
    seen: set[str] = set()
    for score, key, item in scored:
        if key in seen:
            continue
        seen.add(key)
        unique.append((score, item))
        if len(unique) >= limit:
            break

    if not unique:
        return []

    if len(unique) == 1:
        return [unique[0][1]]

    top_score = unique[0][0]
    second_score = unique[1][0]
    if top_score >= 20000 and second_score < 12000:
        return [unique[0][1]]
    if top_score >= 10000 and second_score <= int(top_score * 0.55):
        return [unique[0][1]]

    strong = [item for score, item in unique if score >= max(2500, int(top_score * 0.6))]
    return strong[:limit]


def _safe_decision(raw: Any) -> str:
    value = str(raw or "review").strip().lower()
    allowed = {"consider", "watch", "review", "hold", "avoid"}
    return value if value in allowed else "review"


def _safe_reason(raw: Any) -> str:
    text = str(raw or "").strip()
    if not text:
        return "Useful to review, but full execution stays in the plugin."
    return text[:120]


def _sanitize_reply(reply_json: dict[str, Any], fallback_picks: list[str]) -> dict[str, Any]:
    summary = str(reply_json.get("summary") or "Good items to review, but the plugin handles the full plan.").strip()[:220]
    actions: list[dict[str, str]] = []
    for entry in reply_json.get("actions", []) or []:
        if not isinstance(entry, dict):
            continue
        item = str(entry.get("item") or "").strip()
        if not item:
            continue
        actions.append(
            {
                "item": item[:60],
                "decision": _safe_decision(entry.get("decision")),
                "reason": _safe_reason(entry.get("reason")),
            }
        )
        if len(actions) >= MAX_ACTIONS:
            break

    top_picks: list[str] = []
    for value in reply_json.get("top_picks", []) or []:
        cleaned = str(value or "").strip()
        if cleaned and cleaned not in top_picks:
            top_picks.append(cleaned[:60])
        if len(top_picks) >= MAX_PICKS:
            break
    if not top_picks:
        top_picks = fallback_picks[:MAX_PICKS]

    notes: list[str] = []
    for value in reply_json.get("notes", []) or []:
        cleaned = str(value or "").strip()
        if cleaned:
            notes.append(cleaned[:160])
        if len(notes) >= 2:
            break
    if not any("plugin" in note.lower() for note in notes):
        notes.append("The plugin is where the broader slot-by-slot roadmap and replacement logic lives.")

    return {
        "summary": summary,
        "actions": actions,
        "top_picks": top_picks[:MAX_PICKS],
        "notes": notes[:3],
        "mode": str(reply_json.get("mode") or "web_safe"),
        "plugin_cta": "Use the RuneLite plugin for full slot-by-slot execution.",
    }


def _coerce_json_reply(raw_text: str, fallback_picks: list[str]) -> dict[str, Any]:
    try:
        data = json.loads(raw_text)
        if isinstance(data, dict):
            return _sanitize_reply(data, fallback_picks)
    except Exception:
        pass
    return _sanitize_reply(
        {
            "summary": raw_text[:140] if raw_text else "Good items to review, but the plugin handles the full plan.",
            "actions": [],
            "top_picks": fallback_picks,
            "notes": [],
        },
        fallback_picks,
    )


def _extract_hours(prompt: str) -> int:
    text = _normalize_name(prompt)
    match = re.search(r"(\d{1,3})\s*(?:h|hr|hrs|hour|hours)", text)
    if match:
        return max(1, min(48, _safe_int(match.group(1))))
    if "overnight" in text:
        return 8
    if "all day" in text:
        return 12
    return 0


def _extract_target_quantity(prompt: str) -> int:
    text = _normalize_name(prompt)
    match = re.search(r"(?:buy|sell|flip|get|fill|move)?\s*(\d[\d,]*)\s+[a-z]", text)
    if not match:
        return 0
    value = _safe_int(match.group(1).replace(",", ""))
    return value if 0 < value <= 100_000_000 else 0


def _question_wants_savings(prompt: str) -> bool:
    text = _normalize_name(prompt)
    return any(phrase in text for phrase in ("save money", "cheapest", "cheap", "lowest", "gradually", "over a period", "over time"))


def _classify_query(prompt: str, resolved_items: list[dict[str, Any]]) -> str:
    text = _normalize_name(prompt)
    if any(blocker in text for blocker in NON_OSRS_BLOCKERS):
        return "blocked"
    if any(keyword in text for keyword in PLANNING_KEYWORDS):
        return "portfolio"
    if len(resolved_items) >= 3:
        return "multi_restricted"
    if len(resolved_items) == 2 and any(keyword in text for keyword in COMPARE_KEYWORDS):
        return "dual"
    if len(resolved_items) >= 1:
        return "single"
    if any(keyword in text for keyword in COMPARE_KEYWORDS):
        return "dual"
    return "general"


def _speed_label(volume_1h: int) -> str:
    if volume_1h >= 100_000:
        return "very fast"
    if volume_1h >= 25_000:
        return "fast"
    if volume_1h >= 5_000:
        return "steady"
    if volume_1h > 0:
        return "slower"
    return "unknown"


def _single_item_reply(prompt: str, item_name: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    ctx = build_ai_context_for_query(item_name)
    if not ctx.get("found"):
        return None, {"resolved_item": item_name, "found": False}

    market = ctx.get("current_market", {}) or {}
    ranges = ctx.get("ranges", {}) or {}
    signals = ctx.get("signals", {}) or {}
    canonical_name = str(ctx.get("item_name") or item_name).strip()
    buy_price = _safe_int(market.get("buy_price"))
    sell_price = _safe_int(market.get("sell_price"))
    spread = _safe_int(market.get("spread"))
    profit = _safe_int(market.get("profit_per_item"))
    volume_1h = _safe_int(market.get("recent_volume_1h"))
    buy_limit = _safe_int(market.get("buy_limit"))
    roi_pct = round(_safe_float(market.get("roi_pct")), 3)
    day_low = _safe_int(ranges.get("day_low"))
    day_high = _safe_int(ranges.get("day_high"))
    week_pos = round(_safe_float(ranges.get("week_position_pct")), 1)
    entry_signal = str(signals.get("entry_signal") or "mixed").replace("_", " ")
    advisor_hint = str(signals.get("advisor_hint") or "").strip()
    hours = _extract_hours(prompt)
    target_qty = _extract_target_quantity(prompt)
    prompt_text = _normalize_name(prompt)

    patient_bid = max(1, day_low) if day_low > 0 and day_low <= buy_price else max(1, buy_price)
    nudged_bid = min(sell_price - 1, max(patient_bid, buy_price + max(1, spread // 6))) if sell_price > 0 else patient_bid

    if any(token in prompt_text for token in ("how many", "quantity", "qty")) and hours > 0:
        reset_cycles = max(1, math.ceil(hours / 4))
        personal_cap = buy_limit * reset_cycles if buy_limit > 0 else 0
        market_cap = volume_1h * hours if volume_1h > 0 else 0
        likely_cap = min(v for v in (personal_cap, market_cap) if v > 0) if personal_cap and market_cap else max(personal_cap, market_cap)
        summary = (
            f"{canonical_name} can likely move about {likely_cap:,} in {hours}h if fills stay normal."
            if likely_cap > 0
            else f"{canonical_name} needs a live fill-speed check before sizing an {hours}h window."
        )
        actions = [
            {
                "item": canonical_name,
                "decision": "review",
                "reason": f"Buy limit {buy_limit:,} per 4h cycle; about {reset_cycles} reset windows in {hours}h.",
            },
            {
                "item": "Turnover",
                "decision": "watch",
                "reason": f"Roughly {volume_1h:,}/h recently, so market depth looks {_speed_label(volume_1h)}.",
            },
        ]
        notes = [
            "I would normally compare that fill rate against your other slots before sizing the full roadmap.",
            f"Current read is {entry_signal}; broader slot planning stays in the plugin.",
        ]
    elif target_qty > 0 and (hours >= 6 or _question_wants_savings(prompt)):
        patience_note = f"{target_qty:,} units is tiny versus roughly {volume_1h:,}/h turnover" if volume_1h > 0 else f"{target_qty:,} units is a small enough target to be patient"
        summary = f"For {target_qty:,} {canonical_name} over {hours or 12}h, price matters more than speed."
        actions = [
            {
                "item": canonical_name,
                "decision": "review",
                "reason": f"Start near {_format_gp(patient_bid)} and let it fill; {patience_note}.",
            },
            {
                "item": "Fill pace",
                "decision": "watch",
                "reason": f"If it stays unfilled for too long, nudging toward {_format_gp(nudged_bid)} is still reasonable.",
            },
        ]
        notes = [
            "For a small accumulation over a long window, you usually do not need to chase unless the market is rising.",
            "I’d normally compare this against your full 8-slot setup, but for a one-item buy patience is the edge.",
        ]
    else:
        summary = f"{canonical_name} is around {_format_gp(buy_price)} buy / {_format_gp(sell_price)} sell right now."
        actions = [
            {
                "item": canonical_name,
                "decision": "review",
                "reason": f"A clean entry is near {_format_gp(buy_price)} while the spread stays about {spread:,} gp.",
            },
            {
                "item": "Exit price",
                "decision": "watch",
                "reason": f"Selling near {_format_gp(sell_price)} leaves about {profit:,} gp after tax per item.",
            },
        ]
        notes = [
            f"Recent volume is {volume_1h:,}/h, week-range position is {week_pos:.1f}%, and the entry read looks {entry_signal}.",
            "I’d normally compare this across your full 8-slot setup to see if something rotates faster.",
        ]
        if advisor_hint:
            notes[0] = f"{advisor_hint} Recent volume is {volume_1h:,}/h and week-range position is {week_pos:.1f}%."

    reply = _sanitize_reply(
        {
            "summary": summary,
            "actions": actions,
            "top_picks": [canonical_name],
            "notes": notes,
            "mode": "single_item_market_data",
        },
        [canonical_name],
    )
    debug = {
        "resolved_item": canonical_name,
        "buy_price": buy_price,
        "sell_price": sell_price,
        "spread": spread,
        "profit_per_item": profit,
        "recent_volume_1h": volume_1h,
        "buy_limit": buy_limit,
        "roi_pct": roi_pct,
        "day_low": day_low,
        "day_high": day_high,
        "week_position_pct": week_pos,
        "entry_signal": entry_signal,
        "hours": hours,
        "target_quantity": target_qty,
    }
    return reply, debug


def _dual_item_reply(prompt: str, items: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    contexts = []
    for item in items[:2]:
        ctx = build_ai_context_for_query(str(item.get("name") or ""))
        if ctx.get("found"):
            contexts.append(ctx)
    if len(contexts) < 2:
        return None, {"resolved_items": [str(item.get("name") or "") for item in items[:2]], "found_count": len(contexts)}

    a, b = contexts[0], contexts[1]
    av = _safe_int((a.get("current_market", {}) or {}).get("recent_volume_1h"))
    bv = _safe_int((b.get("current_market", {}) or {}).get("recent_volume_1h"))
    ap = _safe_int((a.get("current_market", {}) or {}).get("profit_per_item"))
    bp = _safe_int((b.get("current_market", {}) or {}).get("profit_per_item"))
    steadier = a if av >= bv else b
    higher_edge = a if ap >= bp else b
    summary = f"For a limited two-item check, {steadier['item_name']} looks steadier while {higher_edge['item_name']} has the better per-item edge."
    reply = _sanitize_reply(
        {
            "summary": summary,
            "actions": [
                {
                    "item": a["item_name"],
                    "decision": "review",
                    "reason": f"About {_format_gp((a.get('current_market', {}) or {}).get('buy_price'))} buy / {_format_gp((a.get('current_market', {}) or {}).get('sell_price'))} sell right now.",
                },
                {
                    "item": b["item_name"],
                    "decision": "review",
                    "reason": f"About {_format_gp((b.get('current_market', {}) or {}).get('buy_price'))} buy / {_format_gp((b.get('current_market', {}) or {}).get('sell_price'))} sell right now.",
                },
            ],
            "top_picks": [steadier["item_name"], higher_edge["item_name"]],
            "notes": [
                "I can compare one or two items here, but the plugin is where the full slot ranking kicks in.",
            ],
            "mode": "dual_item_market_data",
        },
        [steadier["item_name"], higher_edge["item_name"]],
    )
    return reply, {
        "resolved_items": [a["item_name"], b["item_name"]],
        "steadier_item": steadier["item_name"],
        "higher_edge_item": higher_edge["item_name"],
    }


def _premium_boundary_reply(resolved_names: list[str]) -> dict[str, Any]:
    return _sanitize_reply(
        {
            "summary": "I can help with one or two item checks here, but full multi-item planning stays in the plugin.",
            "actions": [
                {
                    "item": resolved_names[0] if resolved_names else "Multi-item planning",
                    "decision": "review",
                    "reason": "The free copilot is for narrow checks, not full slot-by-slot optimization.",
                }
            ],
            "top_picks": resolved_names[:2],
            "notes": [
                "The plugin is where you get the broader roadmap, replacements, and faster 8-slot decisions.",
            ],
            "mode": "premium_boundary",
        },
        resolved_names[:2],
    )


def _natural_fallback_reply(user_message: str, recommendations: dict[str, Any]) -> dict[str, Any]:
    prompt = _clean_user_prompt(user_message).lower()
    summary = "Here is the quick preview I can give from your OSRS trade context."
    actions: list[dict[str, str]] = []
    notes: list[str] = []
    if "12" in prompt or "away" in prompt or "overnight" in prompt:
        summary = "For a longer offline window, remove slower or thinner trades first."
        actions = [
            {"item": "Slowest-moving trades", "decision": "review", "reason": "Most likely to sit idle while you are away."},
            {"item": "Low-margin trades", "decision": "avoid", "reason": "They have less room for drift over time."},
        ]
        notes = ["Steadier, higher-volume items are usually safer when you cannot actively adjust."]
    elif "weak" in prompt or "weakest" in prompt or "replace" in prompt or "cancel" in prompt:
        summary = "I would inspect the weakest slots by movement speed and margin first."
        actions = [
            {"item": "Slow-moving slots", "decision": "review", "reason": "Idle slots tie up budget without much upside."},
            {"item": "Thin-margin holds", "decision": "watch", "reason": "Small edge disappears quickly when prices move."},
        ]
        notes = ["Weak trades usually combine low velocity, low edge, or constant repricing pressure."]
    elif "risk" in prompt:
        summary = "Lower risk usually means favoring steadier fills over sharper but fragile margins."
        actions = [
            {"item": "High-volatility slots", "decision": "review", "reason": "They need more babysitting to stay efficient."},
            {"item": "Steadier volume items", "decision": "consider", "reason": "They tend to be more forgiving over time."},
        ]
        notes = ["You do not need to abandon profit entirely to smooth out risk."]
    else:
        actions = [
            {"item": "Slowest-moving slots", "decision": "review", "reason": "They are the first places I would inspect."},
            {"item": "Budget concentration", "decision": "watch", "reason": "Too much tied to one idea increases downside."},
        ]
        notes = ["I can still help with priorities, tradeoffs, and which trades look safest to review next."]
    picks = []
    for item in (recommendations.get("recommendations", []) or []):
        name = str(item.get("name") or "").strip()
        if name and name not in picks:
            picks.append(name)
        if len(picks) >= 3:
            break
    return _sanitize_reply({"summary": summary, "actions": actions, "top_picks": picks, "notes": notes}, picks)


def _fast_path_reply(user_message: str) -> dict[str, Any] | None:
    prompt = _clean_user_prompt(user_message)
    payload = FAST_PATH_PRESET_REPLIES.get(prompt.lower())
    if not payload:
        return None
    reply_json = _sanitize_reply(
        {
            "summary": payload.get("summary"),
            "actions": payload.get("actions", []),
            "top_picks": [],
            "notes": payload.get("notes", []),
            "mode": "web_fast_path",
        },
        [],
    )
    reply_json["mode"] = "web_fast_path"
    return reply_json


def _recommendation_counts(recommendations: dict[str, Any]) -> dict[str, int]:
    return {bucket: len(recommendations.get(bucket, []) or []) for bucket in ("recommendations", "high_value", "overnight", "anchors", "dump")}


def _recommendation_preview(recommendations: dict[str, Any]) -> list[str]:
    preview: list[str] = []
    for bucket in ("recommendations", "high_value", "overnight", "anchors", "dump"):
        for item in recommendations.get(bucket, []) or []:
            name = str(item.get("name") or "").strip()
            if name and name not in preview:
                preview.append(name)
            if len(preview) >= 5:
                return preview
    return preview


def _build_debug_base(*, settings: dict[str, Any], prompt: str, model: str) -> dict[str, Any]:
    return {
        "prompt": prompt,
        "prompt_chars": len(prompt),
        "requested_model": model,
        "timeout_seconds": AI_TIMEOUT_SECONDS,
        "settings_snapshot": {
            "budget": settings.get("budget", 0),
            "available_slots": settings.get("available_slots", 0),
            "hours_away": settings.get("hours_away", 0),
        },
    }


def build_ai_advice(user_message: str) -> dict[str, Any]:
    total_start = time.perf_counter()
    settings = load_settings()
    prompt = _clean_user_prompt(user_message) or _default_question()
    model = settings.get("openai_model", DEFAULT_MODEL) or DEFAULT_MODEL
    debug = _build_debug_base(settings=settings, prompt=prompt, model=model)

    fast_path_reply = _fast_path_reply(prompt)
    if fast_path_reply:
        debug.update({"mode": "preset_fast_path", "openai_called": False, "matched_preset": prompt.lower(), "total_ms": _timing_ms(total_start)})
        return {
            "model": "preset-fast-path",
            "reply_json": fast_path_reply,
            "raw_reply": "",
            "current_scan": {"offers": []},
            "decisions": {"decisions": []},
            "recommendations": {},
            "debug": debug,
        }

    resolved_items = _resolve_market_items(prompt, limit=4)
    resolved_names = [str(item.get("name") or "").strip() for item in resolved_items]
    classification = _classify_query(prompt, resolved_items)
    debug.update({
        "classification": classification,
        "resolved_items": resolved_names,
        "market_cache_items": len(_load_market_items()),
    })

    if classification == "blocked":
        reply = _sanitize_reply(
            {
                "summary": "I can only help with OSRS market questions, item checks, and trade decisions here.",
                "actions": [{"item": "OSRS markets", "decision": "review", "reason": "Try a Grand Exchange item, spread, margin, or timing question."}],
                "top_picks": [],
                "notes": ["The plugin is focused on GE data, flips, and slot optimization."],
                "mode": "domain_block",
            },
            [],
        )
        debug.update({"mode": "domain_block", "openai_called": False, "total_ms": _timing_ms(total_start)})
        return {"model": "guard-domain-block", "reply_json": reply, "raw_reply": "", "current_scan": {"offers": []}, "decisions": {"decisions": []}, "recommendations": {}, "debug": debug}

    if classification == "single" and resolved_names:
        reply_json, single_debug = _single_item_reply(prompt, resolved_names[0])
        if reply_json:
            debug.update({"mode": "single_item_market_fast_path", "openai_called": False, "single_item": single_debug, "total_ms": _timing_ms(total_start)})
            return {"model": "market-fast-path", "reply_json": reply_json, "raw_reply": "", "current_scan": {"offers": []}, "decisions": {"decisions": []}, "recommendations": {}, "debug": debug}

    if classification == "dual" and len(resolved_names) >= 2:
        reply_json, dual_debug = _dual_item_reply(prompt, resolved_items[:2])
        if reply_json:
            debug.update({"mode": "dual_item_market_fast_path", "openai_called": False, "dual_item": dual_debug, "total_ms": _timing_ms(total_start)})
            return {"model": "market-fast-path", "reply_json": reply_json, "raw_reply": "", "current_scan": {"offers": []}, "decisions": {"decisions": []}, "recommendations": {}, "debug": debug}

    if classification in {"multi_restricted", "portfolio"}:
        reply_json = _premium_boundary_reply(resolved_names)
        debug.update({"mode": "premium_boundary", "openai_called": False, "total_ms": _timing_ms(total_start)})
        return {"model": "premium-boundary", "reply_json": reply_json, "raw_reply": "", "current_scan": {"offers": []}, "decisions": {"decisions": []}, "recommendations": {}, "debug": debug}

    prep_start = time.perf_counter()
    current_scan = get_current_offers()
    decisions = build_trade_decisions(settings=settings, current_scan=current_scan)
    recommendations = build_recommendations(settings=settings, current_scan=current_scan, mode="web_safe")
    debug.update({
        "prep_ms": _timing_ms(prep_start),
        "current_offer_count": len(current_scan.get("offers", []) or []),
        "decision_count": len(decisions.get("decisions", []) or []),
        "recommendation_counts": _recommendation_counts(recommendations),
        "recommendation_preview": _recommendation_preview(recommendations),
    })

    api_key = resolve_openai_api_key(settings)
    if not api_key:
        debug.update({"mode": "no_api_key_fallback", "openai_called": False, "total_ms": _timing_ms(total_start)})
        return {
            "model": "fallback-web-safe",
            "reply_json": _natural_fallback_reply(prompt, recommendations),
            "raw_reply": "",
            "current_scan": current_scan,
            "decisions": decisions,
            "recommendations": recommendations,
            "debug": debug,
        }

    try:
        openai_start = time.perf_counter()
        client = OpenAI(api_key=api_key, timeout=AI_TIMEOUT_SECONDS)
        response = client.responses.create(
            model=model,
            max_output_tokens=180,
            input=[
                {
                    "role": "developer",
                    "content": (
                        "You are an OSRS flipping advisor for the WEBSITE tier. "
                        "Reply with JSON only. No markdown, no prose outside JSON. "
                        "Use this exact schema: "
                        "{"
                        '"summary": string, '
                        '"actions": ['
                        "{"
                        '"item": string, '
                        '"decision": string, '
                        '"reason": string'
                        "}"
                        "], "
                        '"top_picks": [string], '
                        '"notes": [string]'
                        "}. "
                        "Allowed decisions: consider, watch, review, hold, avoid. "
                        "Never output a full GE plan. "
                        "Never assign all 8 slots. "
                        "Never give quantities, capital allocation, or sequential execution steps. "
                        "At most 2 actions, 3 top_picks, and 2 notes before the plugin reminder. "
                        "Keep summary under 22 words. "
                        "Keep each reason under 14 words. "
                        "Sound like a real AI giving a limited preview, not a scripted block. "
                        "Frame the plugin as the place for full optimization and execution guidance."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
        )
        debug["openai_ms"] = _timing_ms(openai_start)
        debug["openai_called"] = True
        debug["response_id"] = getattr(response, "id", None)
    except Exception as e:
        debug.update({
            "mode": "openai_exception_fallback",
            "openai_called": True,
            "error_type": type(e).__name__,
            "error_message": str(e),
            "total_ms": _timing_ms(total_start),
        })
        return {
            "error": f"AI request failed on model {model}: {str(e)}",
            "reply_json": _natural_fallback_reply(prompt, recommendations),
            "model": f"{model}-fallback",
            "debug": debug,
        }

    raw_text = _extract_json_text(response)
    if not raw_text:
        debug.update({"mode": "empty_response_fallback", "raw_reply_chars": 0, "total_ms": _timing_ms(total_start)})
        return {
            "model": f"{model}-fallback",
            "reply_json": _natural_fallback_reply(prompt, recommendations),
            "raw_reply": "",
            "current_scan": current_scan,
            "decisions": decisions,
            "recommendations": recommendations,
            "debug": debug,
        }

    fallback_picks = _recommendation_preview(recommendations)[:3]
    reply_json = _coerce_json_reply(raw_text, fallback_picks)
    debug.update({
        "mode": "openai_success",
        "raw_reply_chars": len(raw_text),
        "reply_mode": reply_json.get("mode"),
        "total_ms": _timing_ms(total_start),
    })

    return {
        "model": model,
        "reply_json": reply_json,
        "raw_reply": raw_text,
        "current_scan": current_scan,
        "decisions": decisions,
        "recommendations": recommendations,
        "debug": debug,
    }
